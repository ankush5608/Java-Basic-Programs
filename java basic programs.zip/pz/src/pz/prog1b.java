package pz;
import java.util.Scanner;

public class prog1b {

	public static void main (String[] args)
	{
		Scanner sc = new Scanner(System.in);
		double a;
		System.out.println("Enter the coefficients of quadratic term");
		a = sc.nextFloat();
		if(a==0)
		{
			System.out.println("Coefficient of quadratic term cannot be zero");
		}
		
		else
		{
			double b = sc.nextFloat();
			double c = sc.nextFloat();
			double z= b*b -(4*a*c);
			
			equationcheck ob = new equationcheck();
			if(z==0)
			{
				System.out.println("Roots are real and equal");
//				double x1 =  -b/2*a;
//				double x2 = x1;
//				System.out.println("x1 = "+x1+" and x2 = "+x2);
				ob.check(a, b, c);
				ob.display();
			}
			
			else if(z>0)
			{
				System.out.println("Roots are real and distinct");
//				double x1 =  (-b + Math.pow(z, 0.5))/(2*a);
//				double x2 = (-b - Math.pow(z, 0.5))/(2*a);
//				System.out.println("x1 = "+x1+" and x2 = "+x2);
				ob.check(a, b, c);
				ob.display();
			}
			
			else
			{
				System.out.println("no real roots");
			}
		}
	}
}

class equationcheck
{
	double a;
	double b;
	double c;
	double x1;
	double x2;
	
	public void check(double a , double b, double c)
	{
		this.a = a;
		this.b = b;
		this.c = c;
		x1 = (-b + Math.pow((b*b)-(4*a*c), 0.5))/(2*a);
		x2 = (-b - Math.pow((b*b)-(4*a*c), 0.5))/(2*a);
	}
	
	public void display()
	{
		System.out.println(x1);
		System.out.println(x2);
	}
}
