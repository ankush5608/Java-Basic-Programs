package pz;

public class p4b {

	public void savings()
	{
		System.out.println("savings");
	}
	
	private void password()
	{
		System.out.println("password");
	}
	
	protected void data()
	{
		System.out.println("data");
	}
	
	
	public static void main(String[] args)
	{
		p4b p2= new p4b();
		p2.password();
		p2.data();
		p2.savings();
	}
}
