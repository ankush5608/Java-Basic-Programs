package pz;

public class gchild extends child{

	public void bike2()
	{
		System.out.println("bike2");
	}
	
	public static void main(String[] args)
	{
		gchild g = new gchild();
		g.bike();
		g.bike2();
		g.house();
		g.land();
	}
}
