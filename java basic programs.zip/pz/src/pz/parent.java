package pz;

public class parent {

	public void land()
	{
		System.out.println("land");
		
		
	}
	
	
	public void house()
	{
		System.out.println("house");
	}
	public static void main(String[] args)
	{
		parent p = new parent();
		p.house();
		p.land();
	}
}
