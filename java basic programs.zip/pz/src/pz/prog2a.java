package pz;
import java.util.Scanner;

class employee
{
	int id;
	String name;
	String desig;
	float salary;
}
public class prog2a {
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int n;
		System.out.println("Enter number of employees");
		n= sc.nextInt();
		employee emp[] = new employee[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter details of employee "+(i+1));
			emp[i] = new employee();
			System.out.println("Enter id");
			emp[i].id = sc.nextInt();
			System.out.println("Enter name");
			emp[i].name = sc.next();
			System.out.println("Enter desig");
			emp[i].desig = sc.next();
			System.out.println("Enter salary");
			emp[i].salary = sc.nextFloat();
		}
		
		System.out.println("Employee details are:");
		for(int i=0;i<n;i++)
		{
			System.out.println("id "+emp[i].id + " name "+ emp[i].name+" desig "+emp[i].desig+" salary "+emp[i].salary);
		}
	}
}
