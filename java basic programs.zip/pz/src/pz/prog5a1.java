package pz;

public class prog5a1 {

	public static void main(String[] args)
	{
		double length=2.0;
		double breadth=3.0;
		rectangle r = new rectangle(length,breadth);
		System.out.println("area "+r.area());
		System.out.println("perimeter "+r.perimeter());
		
		double radius=2.0;
		circle c = new circle(radius);
		System.out.println("area "+c.area());
		System.out.println("perimeter "+c.perimeter());
	}
}
