package pz;

public class child extends parent{

	public void bike()
	{
		System.out.println("bike");
	}
	
	public static void main(String[] args)
	{
		child c = new child();
		c.land();
		c.house();
		c.bike();
	}
}
