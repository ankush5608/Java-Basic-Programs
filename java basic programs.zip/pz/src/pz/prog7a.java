package pz;
import java.util.Arrays;
public class prog7a {

	public static void main(String[] args)
	{
		String str1="Race";
		String str2="cArre";
		
		str1=str1.toLowerCase();
		str2 = str2.toLowerCase();
		
		if(str1.length()==str2.length())
		{
			char[] chararray1 = str1.toCharArray();
			char[] chararray2 = str2.toCharArray();
			
			Arrays.sort(chararray1);
			Arrays.sort(chararray2);
			
			boolean results = Arrays.equals(chararray1, chararray2);
			
			if(results)
			{
				System.out.println("anagram");
			}
			
			else
			{
				System.out.println("not anagram");
			}
		}
		
		else
		{
			System.out.println("not anagram");
		}
	}
}
