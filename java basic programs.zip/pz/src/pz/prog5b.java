package pz;

import java.sql.*;

public class prog5b {

	public static void main(String[] args)
	{
		try
		{
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","aiml123");
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from db_table");
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+" " +rs.getString(2));
			
			
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
}
