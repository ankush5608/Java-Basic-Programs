package pz;
import java.util.Random;

public class prog2b {

	public static void main(String[] args)
	{
		Random rand = new Random();
		int frequency1=0;
		int frequency2=0;
		int frequency3=0;
		int frequency4=0;
		int frequency5=0;
		int frequency6=0;
		
		for(int i=0;i<1000;i++)
		{
		int randint = rand.nextInt(1,7);
		switch(randint)
		{
		case 1: ++frequency1;
		        break;
		case 2: ++frequency2;
        break;
		case 3: ++frequency3;
        break;
		case 4: ++frequency4;
        break;
		case 5: ++frequency5;
        break;
		case 6: ++frequency6;
        break;      
		}
		}
		
		System.out.println("face \t frequency");
		System.out.println("1\t "+frequency1+" 2\t "+ frequency2 + " 3\t "+frequency3 + " 4\t "+frequency4 + " 5\t "+frequency5+" 6\t "+frequency6);
		
	}
}
