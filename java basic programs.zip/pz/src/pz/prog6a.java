package pz;

public class prog6a {

	public static void main(String[] args)
	{
		try
		{
			try
			{
				System.out.println("dividing by zero");
				int b=39/0;
			}
			
			catch(ArithmeticException e)
			{
				System.out.println(e);
			}
			
			try
			{
				System.out.println("Array index out of bound");
				int arr[] = new int[5];
				arr[5]=6;
			}
			
			catch(ArrayIndexOutOfBoundsException e)
			{
				System.out.println(e);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
