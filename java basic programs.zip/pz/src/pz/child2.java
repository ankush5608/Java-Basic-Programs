package pz;

public class child2 extends parent{

	public void bikealt()
	{
		System.out.println("bikealt");
	}
	
	public static void main(String[] args)
	{
		child2 c2= new child2();
		c2.house();
		c2.bikealt();
		c2.land();
	}
}
