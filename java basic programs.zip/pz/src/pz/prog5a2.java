package pz;
interface shape
{
	double area();
	double perimeter();
}

class rectangle implements shape
{
	private double length;
	private double breadth;
	
	public rectangle(double length,double breadth)
	{
		this.length=length;
		this.breadth=breadth;
	}
	
	public double area()
	{
		return length*breadth;
	}
	
	public double perimeter()
	{
		return 2*(length+breadth);
	}
}
class circle implements shape
{
	private double radius;
	
	public circle(double radius)
	{
		this.radius=radius;
	}
	
	public double area()
	{
		return radius*Math.PI*radius;
	}
	
	public double perimeter()
	{
		return 2*Math.PI*radius;
	}
}

