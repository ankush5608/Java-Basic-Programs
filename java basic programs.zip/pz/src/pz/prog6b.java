package pz;
import java.util.Random;


class square extends Thread
{
	int x;
	square(int n)
	{
		x=n;
	}
	
	public void run()
	{
		int sqr=x*x;
		System.out.println("Square "+sqr);
	}
}

class cube extends Thread
{
	int x;
	cube(int n)
	{
		x=n;
	}
	
	public void run()
	{
		int cub=x*x*x;
		System.out.println("cube "+cub);
	}
}

class number extends Thread
{
	public void run()
	{
		Random rand=new Random();
		for(int i=0;i<10;i++)
		{
		int randint = rand.nextInt(100);
		System.out.println("random integer generated is "+randint);
		square s = new square(randint);
		s.start();
		cube c = new cube(randint);
		c.start();
		
		
		try
		{
			Thread.sleep(1000);
		}
		
		catch(InterruptedException e)
		{
			System.out.println(e);
		}
		}
	}
}

public class prog6b {
	
	public static void main(String[] args)
	{
		number n = new number();
		n.start();
	}
	
}
