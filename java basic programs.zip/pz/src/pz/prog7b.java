package pz;

import java.io.*;

public class prog7b {

	public static void main (String[] args) throws IOException
	{
		File file = new File("C:/Users/win10/OneDrive/Desktop/bbbbbbbbb.txt");
		FileInputStream fileInputStream = new FileInputStream(file);
		InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		
		String line;
		int wordcount=0;
		int paracount=0;
		int charcount=0;
		int sentencecount=0;
		int whitespacecount=0;
		
		while((line = bufferedReader.readLine())!=null)
		{
			if(line.equals(""))
			{
				paracount+=1;
			}
			
			else
			{
				charcount+=line.length();
				String words[] = line.split("\\s+");
				wordcount+=words.length;
				whitespacecount+=wordcount-1;
				String sentence[]=line.split("[!.:?]+");
				sentencecount+= sentence.length;
			}
		}
		
		if(sentencecount>=1)
		{
			paracount++;
		}
		
		System.out.println("paras "+paracount);
		System.out.println("sentences "+sentencecount);
		System.out.println("char "+charcount);
		System.out.println("whitespace "+whitespacecount);
		System.out.println("word "+wordcount);
	}
}
