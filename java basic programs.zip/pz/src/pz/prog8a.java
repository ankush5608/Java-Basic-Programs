package pz;

public class prog8a {

	public static void main(String[] args)
	{
		String str1 = "good morning have a good day";
		String old = "good";
		String new_ = "very good";
		String fin = str1.replaceAll(old,new_);
		System.out.println(fin);
	}
}

class replace
{
	public static void main(String[] args)
	{
		String org = "this is mine and this is too";
		String search = "is";
		String sub = "was";
		String res;
		int i;
		
		do
		{
			System.out.println(org);
			i = org.indexOf(search);
			if(i!=-1)
			{
				res = org.substring(0,i);
				res = res+sub;
				res = res+org.substring(i+search.length());
				org = res;
			}
		}while(i!=-1);
	}
}