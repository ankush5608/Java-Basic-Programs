package pz;

public class prog3a {

	public prog3a()
	{
		this(5);
		System.out.println("constructor chaining");
	}
	
	public prog3a(int a)
	{
		this(5,5);
		System.out.println(a);
	}
	
	public prog3a(int a,int b)
	{
		this("alpha");
		System.out.println(a+b);
	}
	
	public prog3a(String s)
	{
		System.out.println(s);
	}
	
	public static void main(String[] args)
	{
		prog3a a=new prog3a();
	}
	
}
