package pz;

import java.sql.*;

public class sql {

	public static void main(String[] args)
	{
		try
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","aiml123");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from db_table");
			
			while(rs.next())
			{
				System.out.println("id: "+rs.getInt(1)+" name "+rs.getString(2));
			}
		}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
