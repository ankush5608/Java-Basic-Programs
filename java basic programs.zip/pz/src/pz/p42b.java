package pz;

public class p42b extends p4b{

	public static void main(String[] args)
	{
		p42b p = new p42b();
		p.data();
		p.savings();
//		p.password();
	}
}
