/**
 * 
 */
/**
 * 
 */
module pz {
	requires java.sql;
}